package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"bytes"
	"encoding/binary"
)

var (
	user = "tpucode"
	pwd = "123456"
)

func main() {
	//"6f5b0bbb35225b1d39fe687351052054"
	tokenInfo :=new(bytes.Buffer)
	binary.Write(tokenInfo, binary.LittleEndian, uint16(3))
	binary.Write(tokenInfo, binary.LittleEndian, uint16(22))
	binary.Write(tokenInfo, binary.LittleEndian, uint16(32))
	binary.Write(tokenInfo, binary.LittleEndian, []byte("6f5b0bbb35225b1d39fe687351052054"))

	body := ioutil.NopCloser(tokenInfo)
	client := &http.Client{}
	req, err := http.NewRequest("POST", "http://172.16.13.27:8080/upgrade", body)

	if err != nil {
		fmt.Println(err)
	}

	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")
	resp, _ := client.Do(req) //发送

	defer resp.Body.Close()     //一定要关闭resp.Body
	datas, _ := ioutil.ReadAll(resp.Body)
	fmt.Println(datas)

	fmt.Println(string(datas[1:]))

	//fmt.Println(hex.EncodeToString(datas), err)
}