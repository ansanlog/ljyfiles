package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"bytes"
	"encoding/binary"
)

var (
	user = "tpucode"
	pwd = "123456"
)

func main() {

	DownloadInfo :=new(bytes.Buffer)
	binary.Write(DownloadInfo, binary.LittleEndian, uint16(4))
	binary.Write(DownloadInfo, binary.LittleEndian, uint16(22))
	binary.Write(DownloadInfo, binary.LittleEndian, uint16(34))
	binary.Write(DownloadInfo, binary.LittleEndian, []byte("6f5b0bbb35225b1d39fe687351052054"))
	binary.Write(DownloadInfo, binary.LittleEndian, uint16(5))

	body := ioutil.NopCloser(DownloadInfo)
	client := &http.Client{}
	req, err := http.NewRequest("POST", "http://172.16.13.27:8080/upgrade", body)
	if err != nil {
		fmt.Println(err)
	}

	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")

	resp, _ := client.Do(req) //发送

	defer resp.Body.Close()     //一定要关闭resp.Body
	datas, _ := ioutil.ReadAll(resp.Body)
	fmt.Println(datas)

	fmt.Println(string(datas[1:]))

}