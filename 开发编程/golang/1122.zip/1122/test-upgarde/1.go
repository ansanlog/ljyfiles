package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"bytes"
	"encoding/binary"
)

var (
	user = "tpucode"
	pwd = "123456"
)

func main() {
	userInfo := new(bytes.Buffer)
	binary.Write(userInfo, binary.LittleEndian, uint16(2))
	binary.Write(userInfo, binary.LittleEndian, uint16(22))
	binary.Write(userInfo, binary.LittleEndian, uint16(17))
	binary.Write(userInfo, binary.LittleEndian, uint16(7))
	binary.Write(userInfo, binary.LittleEndian, []byte("tpucode"))
	binary.Write(userInfo, binary.LittleEndian, uint16(6))
	binary.Write(userInfo, binary.LittleEndian, []byte("123456"))


	body := ioutil.NopCloser(userInfo)
	client := &http.Client{}
	req, err := http.NewRequest("POST", "http://172.16.13.27:8080/upgrade", body)
	if err != nil {
		fmt.Println(err)
	}
	req.Header.Add("Content-Type", "application/x-www-form-urlencoded")
	resp, _ := client.Do(req) //发送

	defer resp.Body.Close()     //一定要关闭resp.Body
	datas, _ := ioutil.ReadAll(resp.Body)
	fmt.Println(datas)

	fmt.Println(string(datas[1:]))

	//fmt.Println(hex.EncodeToString(datas), err)
}