package main

import "fmt"

func main(){
	/*var num int=32*/
	var  ui16  uint16= 10
	fmt.Printf(int(ui16))
	//fmt.Println(int(ui16>>16))
}
