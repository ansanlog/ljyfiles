#!/bin/bash
#
# build
#
function check(){
    if [ $? -ne 0 ];then
        exit $1
    fi
}

# 执行单元测试
#go test ./...
#check 2

# 执行编译
rootDir=$(cd "$(dirname $0)"; pwd)
version=$(git rev-list HEAD | wc -l)

# 1) 编译monitor
webDir="$rootDir/"
cd $webDir
export CGO_ENABLED=0
bee pack -ba "-ldflags '-w'" -o beepack
check 1

cd beepack
check 1

tar -zxf mifpay-upgrade-services.tar.gz
rm -rf mifpay-upgrade-services.tar.gz
dbuild --repo=$1 --name=mifpay-upgrade-services --tag=$version --registry-url=172.16.18.100:5000 --service-url=http://172.16.20.18:50000 --login-name=mifpay --login-pwd=123456 --work-dir=`pwd`
rst=$?
cd $webDir
rm -rf beepack
if [ $rst -ne 0 ];then
    exit 1
fi


#
# deploy process
#
# function deploy(){
#    kubectl -s $1 rolling-update --image-pull-policy=Always mifpay-monitor --image=172.16.18.100:5000/$2/mifpay-monitor:$version
#    check 1

#    path="/home/mifpay/nginx/store/$3/mifpay-monitor/$(date +%Y-%m-%d)"
#   ssh mifpay@172.16.18.165 "mkdir -p $path"
#    check 1
#    echo "send mproc to store completed."
# }
# case $1 in
#    "dev")
#       deploy "http://172.16.20.4:8080" "dev" "develop"
#        ;;
#    "release")
#        deploy "http://172.16.21.11:8080" "release" "release"
#        ;;
# esac