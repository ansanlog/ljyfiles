package controllers

import (
	"bytes"
	"encoding/binary"
	"strings"
	"os"
)

func setResultReceipt(res []byte) (repPkg []byte) {
	var dataLen, status uint16

	// 数据总长度
	bufDataLen := bytes.NewBuffer(res[4:6])
	binary.Read(bufDataLen, binary.LittleEndian, &dataLen)

	newRes := res[6:(6 + dataLen)]
	// token
	token := newRes[0:32]

	if strings.EqualFold(getToken(gettokenData()), string(token)) {
		resultStatus := newRes[32:]
		bufResultStatus := bytes.NewBuffer(res[4:6])
		binary.Read(bufResultStatus, binary.LittleEndian, &status)

		if status == 0 {
			// 删除文件fileDir
			err := os.Remove(fileDir) // 删除文件fileDir
			check(err)
			// 清空集合
			fileCache = make(map[int][]byte)
		}
		buf := new(bytes.Buffer)
		binary.Write(buf, binary.LittleEndian, token) // token
		binary.Write(buf, binary.LittleEndian, resultStatus) // 结果
		repPkg =buf.Bytes()
	}

	return repPkg
}
