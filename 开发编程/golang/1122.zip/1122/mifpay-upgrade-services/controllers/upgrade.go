package controllers
/*
  根据接收到的数据，截取命令字转化为整形，由命令字决定做哪种操作
*/

import (
	"github.com/astaxie/beego"
	"bytes"
	"encoding/binary"
	"fmt"
)

const (
	cmd_login = 0x02
	cmd_req_info = 0x03
	cmd_download = 0x04
	cmd_notice = 0x05
)

type UpgradeController struct {
	beego.Controller
}

func (this *UpgradeController) Post() {
	var CMD uint16
	res := this.Ctx.Input.RequestBody

	byteCWD := res[0:2]
	bufByteCWD := bytes.NewBuffer(byteCWD)
	binary.Read(bufByteCWD, binary.LittleEndian, &CMD)

	switch CMD {
	case cmd_login:

		fmt.Println(login(res))
		this.Ctx.Output.Body(login(res))
	/*this.Ctx.ResponseWriter.ResponseWriter.Write(login(res))*/
	case cmd_req_info:

		/*fmt.Println(upgradePkg(res))*/
		this.Ctx.Output.Body(upgradePkg(res))
	/*this.Ctx.ResponseWriter.ResponseWriter.Write(upgradePkg(res))*/
	case cmd_download:
		fmt.Println(getPkgBlock(res))
		this.Ctx.Output.Body(getPkgBlock(res))
	/*this.Ctx.ResponseWriter.ResponseWriter.Write(getPkgBlock(res))*/

	case cmd_notice:
		this.Ctx.Output.Body(setResultReceipt(res))
	/*this.Ctx.ResponseWriter.ResponseWriter.Write(setResultReceipt(res))*/
	default:
		// 无法识别，回复0X9F0F
		buf := new(bytes.Buffer)
		binary.Write(buf, binary.LittleEndian, int16(3999))
		this.Ctx.Output.Body(buf.Bytes()[0:2])
	/*this.Ctx.ResponseWriter.ResponseWriter.Write([]byte("Unable to identify the key words"))*/
	}

}