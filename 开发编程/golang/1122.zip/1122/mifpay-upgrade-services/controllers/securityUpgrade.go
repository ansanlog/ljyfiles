package controllers

import (
	"github.com/astaxie/beego"
	"fmt"
	"mifpay-upgrade-services/models"
	"strings"
	"encoding/hex"
	"os"
	"strconv"
	"bytes"
	"time"

)

type SecurityController struct {
	beego.Controller
}

const DATETIME_LAYOUT = "20060102"

// 生成安全策略版本BLE升级包
func (c *SecurityController) GenerateUpgrade() {

	var versionStr = c.GetString("version")
	//如果版本号参数为空，直接返回页面，提示version is empty
	if !(len(versionStr) > 0) {
		fmt.Printf("version is empty \n")
		c.Ctx.WriteString("参数为空，请添加参数version数值！")
	} else {
		version, _ := strconv.Atoi(versionStr)
		var securityPcode *models.SecurityPcode
		var incrementalFactor string
		var pcodeMd5 string
		var tpuPcode []byte
		var versionArr [2]byte
		versionArr[0] = byte(version)
		versionArr[1] = byte(version >> 8)
		//根据版本号查询数据，状态：未启用
		var securityKeyVersion *models.SecurityKeyVersion = models.QuerySecurityKeyVersion(version)
		if securityKeyVersion != nil {
			version = securityKeyVersion.Version
			incrementalFactor = securityKeyVersion.IncrementalFactor
			pcodeMd5 = securityKeyVersion.PcodeMd5
			//查询Pcode数据
			securityPcode = models.QuerySecurityPcode(pcodeMd5)
			if (securityPcode != nil) {
				buf := bytes.NewBufferString(securityPcode.TpuPcode)
				tpuPcode = buf.Bytes();
			}

			//查询当前启用的数据，状态：已启用
			var securityEnableVersion *models.SecurityKeyVersion = models.QueryCurrentEnableVersion()
			if securityEnableVersion != nil {
				fmt.Printf("安全策略版本号：0x%X ，PcodeMd5：%s \n", versionArr, pcodeMd5)
				fmt.Printf("当前启用的安全策略版本PcodeMd5：%s \n", securityEnableVersion.PcodeMd5)
				if strings.EqualFold(pcodeMd5, securityEnableVersion.PcodeMd5) {
					//与启用版本Pcode相同，则不用下发Pcode，用0x00替换
					tpuPcode = []byte{0x00}
				}

			}

			//增量因子转为字节数据
			iFactor, err := hex.DecodeString(incrementalFactor)
			if (err != nil) {
				fmt.Errorf("incrementalFactor transcoding error : %s\n", err)
			}
			//增量因子转为两个字节数据
			var iFactorLen = len(iFactor)
			fmt.Printf("增量因子长度 %d 字节\n", iFactorLen)
			var iFactorLenArr [2]byte
			iFactorLenArr[0] = byte(iFactorLen)
			iFactorLenArr[1] = byte(iFactorLen >> 8)

			//PCode转为四个字节数据
			var tpuPcodeLen = len(tpuPcode)
			fmt.Printf("Pcode长度 %d 字节\n", tpuPcodeLen)
			var tpuPcodeLenArr [4]byte
			tpuPcodeLenArr[0] = byte(tpuPcodeLen)
			tpuPcodeLenArr[1] = byte(tpuPcodeLen >> 8)
			tpuPcodeLenArr[2] = byte(tpuPcodeLen >> 16)
			tpuPcodeLenArr[3] = byte(tpuPcodeLen >> 24)

			var bifac = iFactorLenArr[0:2]

			var bfactor []byte
			bfactor = append(bifac)
			//拼接增量因子字节数据
			for _, v := range iFactor {
				bfactor = append(bfactor, v)
			}
			//拼接PCode长度字节数据
			for _, v := range tpuPcodeLenArr {
				bfactor = append(bfactor, v)
			}
			//拼接PCode字节数据
			for _, v := range tpuPcode {
				bfactor = append(bfactor, v)
			}

			var date = time.Now().Format(DATETIME_LAYOUT)
			versionslice := versionArr[0:2]
			var bufestr = hex.EncodeToString(versionslice)

			var fileName = "security_" + date + "_" + bufestr
			fmt.Printf(fileName + "：待写入 %d 字节数据\n", len(bfactor))
			f, err1 := os.Create("./security/" + fileName)  //创建文件
			check(err1)
			defer f.Close()
			n2, err2 := f.Write(bfactor)  //写入文件(字节数组)
			check(err2)
			f.Sync()
			fmt.Printf(fileName + "：成功写入 %d 字节数据\n", n2)
			if err != nil {
				fmt.Errorf("write file error : %s", err)
				c.Ctx.WriteString("二进制文件包生成失败!")
			}
			c.Ctx.WriteString("二进制文件包生成成功!")
		} else {
			c.Ctx.WriteString("没有该版本的数据，请重新输入版本号数值!")
		}
	}
}

func check(e error) {
	if e != nil {
		panic(e)
	}
}