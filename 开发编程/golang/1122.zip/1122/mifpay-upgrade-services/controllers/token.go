package controllers

import (
	"crypto/md5"
	"encoding/hex"
)

// 通过MD5加密，生成token
func getToken(b []byte) (cipherStr string) {
	md5Ctx := md5.New()
	md5Ctx.Write(b)
	cipherStr = hex.EncodeToString(md5Ctx.Sum(nil))
	return cipherStr
}

