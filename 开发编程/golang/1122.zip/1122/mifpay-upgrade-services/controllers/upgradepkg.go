package controllers

import (
	"bytes"
	"github.com/astaxie/beego"
	"path/filepath"
	"os"
	"encoding/binary"
	"strings"
	"fmt"
)

var (
	fileSize int
	fileName string
	fileHash []byte
	blockNum int
	fileCache map[int][]byte
	fileDir string
)

func upgradePkg(res []byte) (repPkg []byte) {

	var dataLen uint16
	// 数据总长度
	bufDataLen := bytes.NewBuffer(res[4:6])
	binary.Read(bufDataLen, binary.LittleEndian, &dataLen)

	newRes := res[6:(6 + dataLen)]

	// token
	if strings.EqualFold(getToken(gettokenData()), string(newRes)) {
		// 结果/哈希值/分块数量/文件名长度/文件名
		buf := new(bytes.Buffer)
		binary.Write(buf, binary.LittleEndian, uint8(0)) // 结果

		fileSize = beego.AppConfig.DefaultInt("blockSize", 512)
		getfile(beego.AppConfig.String("fileDir"))
		//fmt.Println("路径", beego.AppConfig.String("fileDir"), fileDir)
		fileName, fileHash, blockNum = getFileInfo(fileDir, fileSize)

		binary.Write(buf, binary.LittleEndian, uint8(0)) // 结果
		binary.Write(buf, binary.LittleEndian, fileHash) // 哈希值
		binary.Write(buf, binary.LittleEndian, uint16(blockNum)) // 分块数量
		binary.Write(buf, binary.LittleEndian, uint16(len(fileName))) // 文件名长度
		binary.Write(buf, binary.LittleEndian, []byte(fileName)) // 文件名
		repPkg = buf.Bytes()

	} else {
		// 若获取失败，无哈希值与分块数量
		buf := new(bytes.Buffer)
		binary.Write(buf, binary.LittleEndian, uint8(1))
		repPkg = buf.Bytes()
	}
	return repPkg

}

func getfile(filePath string) error {
	filepath.Walk(filePath,
		func(path string, f os.FileInfo, err error) error {
			if f == nil {
				return err
			}
			if f.IsDir() {
				//fmt.Println("dir:", path)
				return nil
			}
			//fmt.Println("file:", path)
			fileDir = path
			return nil
		})
	return nil
}


