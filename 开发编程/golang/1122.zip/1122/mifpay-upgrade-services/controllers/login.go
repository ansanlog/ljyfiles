package controllers

import (
	"github.com/astaxie/beego"
	"strings"
	"bytes"
	"encoding/binary"
)

func login(res []byte) (repPkg []byte) {

	var start, end, dataLen, resUserlen, relPwdLen uint16
	// 数据总长度
	bufDataLen := bytes.NewBuffer(res[4:6])
	binary.Read(bufDataLen, binary.LittleEndian, &dataLen)
	// 新切片
	newRes := res[6:6 + dataLen]
	// 用户长度
	bufResUserlen := bytes.NewBuffer(newRes[0:2])
	binary.Read(bufResUserlen, binary.LittleEndian, &resUserlen)

	// 用户名
	end = resUserlen + 2
	resUser := newRes[2:end]

	start = end
	end = end + 2
	// 密码长度
	bufRelPwdLen := bytes.NewBuffer(newRes[start:end])
	binary.Read(bufRelPwdLen, binary.LittleEndian, &relPwdLen)
	// 密码
	start = end
	end = end + relPwdLen
	resPwd := newRes[start:end]

	// 调用MD5，生成token
	if strings.EqualFold(beego.AppConfig.String("user"), string(resUser))&& strings.EqualFold(beego.AppConfig.String("pwd"), string(resPwd)) {
		/*tokenInfo := new(bytes.Buffer)
		binary.Write(tokenInfo, binary.LittleEndian, resUser)
		binary.Write(tokenInfo, binary.LittleEndian, resPwd)*/
		// 应答包
		loginInfo := new(bytes.Buffer)
		binary.Write(loginInfo, binary.LittleEndian, uint8(0))
		binary.Write(loginInfo, binary.LittleEndian, []byte(getToken(gettokenData())))
		repPkg = loginInfo.Bytes()

	} else {
		// 若获取失败，无哈希值与分块数量
		buf := new(bytes.Buffer)
		binary.Write(buf, binary.LittleEndian, uint8(1))
		repPkg = buf.Bytes()
	}
	return repPkg
}

func gettokenData()[]byte{
	tokenInfo := new(bytes.Buffer)
	binary.Write(tokenInfo, binary.LittleEndian, []byte(beego.AppConfig.String("user")))
	binary.Write(tokenInfo, binary.LittleEndian, []byte(beego.AppConfig.String("pwd")))
	return tokenInfo.Bytes()
}
