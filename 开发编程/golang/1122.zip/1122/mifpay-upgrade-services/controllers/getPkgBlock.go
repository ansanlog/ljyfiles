package controllers

import (
	"bytes"
	"encoding/binary"
	"strings"
	"fmt"
)

func getPkgBlock(res []byte) (repPkg []byte) {

	var (
		dataLen uint16
		blockNum uint16
	)

	// 数据总长度
	bufDataLen := bytes.NewBuffer(res[4:6])
	fmt.Println(res[4:6])
	binary.Read(bufDataLen, binary.LittleEndian, &dataLen)
	fmt.Println(dataLen)
	newRes := res[6:(6 + dataLen)]
	token := newRes[0:32] // token
	fmt.Println(string(token))

	if strings.EqualFold(getToken(gettokenData()), string(token)) {
		// 分块号
		blockNumByte := newRes[32:]
		fmt.Printf("%b",blockNumByte)
		bufBlockNum := new(bytes.Buffer)
		//bufBlockNum := bytes.NewBuffer(blockNumByte)

		binary.Write(bufBlockNum, binary.LittleEndian, blockNumByte)
		binary.Write(bufBlockNum, binary.LittleEndian, uint16(0))
		binary.Read(bufBlockNum, binary.LittleEndian, &blockNum)
		fmt.Printf("%b",bufBlockNum.Bytes())
		fmt.Printf("%b",int32(9))
		fmt.Printf("%b",blockNum)
		fmt.Println(blockNum)
		iblockNum:=int(blockNum)
		fmt.Println(iblockNum)
		// 结果/数据块大小/数据
		buf := new(bytes.Buffer)
		binary.Write(buf, binary.LittleEndian, uint8(0)) // 结果
		binary.Write(buf, binary.LittleEndian, uint16(len(fileCache[iblockNum]))) // 数据块大小
		binary.Write(buf, binary.LittleEndian, fileCache[iblockNum]) // 数据

		for k,v:=range fileCache {
			fmt.Println(k,v)

		}
		repPkg = buf.Bytes()

		fmt.Println(repPkg)
	} else {
		// 若获取失败，无哈希值与分块数量
		buf := new(bytes.Buffer)
		binary.Write(buf, binary.LittleEndian, uint8(1))
		repPkg = buf.Bytes()
	}
	return repPkg
}
