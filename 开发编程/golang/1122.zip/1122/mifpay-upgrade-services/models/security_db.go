package models

import (
	"fmt"
	"github.com/astaxie/beego"
	"github.com/astaxie/beego/orm"
	_ "github.com/go-sql-driver/mysql"
)

//初始化数据库连接
func init() {
	//TODO 生产环境不要开启Debug
	orm.Debug = true
	orm.RegisterDriver("mysql", orm.DRMySQL)

	var dataSourceTpl string = `%s:%s@tcp(%s:%s)/%s?charset=utf8`
	var dataSource string = fmt.Sprintf(dataSourceTpl, beego.AppConfig.String("mysql_user"), beego.AppConfig.String("mysql_pwd"), beego.AppConfig.String("mysql_host"), beego.AppConfig.String("mysql_port"), beego.AppConfig.String("mysql_db"))

	maxIdle, err := beego.AppConfig.Int("mysql_max_idle")
	maxConn, err := beego.AppConfig.Int("mysql_max_conn")

	orm.RegisterDataBase("default", "mysql", dataSource, maxIdle, maxConn)

	if err != nil {
		fmt.Errorf("Error: %s", err)
	}

}

//SecurityKeyVersion 持久层对象
type SecurityKeyVersion struct {
	VersionId         int
	Version           int
	Status            int
	IncrementalFactor string
	PcodeMd5          string
}

// SecurityPcode 持久层对象
type SecurityPcode struct {
	PcodeId      uint32
	PcodeMd5     string
	TpuPcodeName string
	TpuPcode     string
	TpuPcodeMd5  string
}

//根据版本号version 查询单个SecurityKeyVersion
func QuerySecurityKeyVersion(version int) *SecurityKeyVersion {
	o := orm.NewOrm()
	var r orm.RawSeter
	var skv *SecurityKeyVersion
	r = o.Raw("SELECT version_id,version,status,incremental_factor,pcode_md5 FROM security_key_version WHERE del_flag = 1 AND status = 0 AND version = ?", version)
	err := r.QueryRow(&skv)
	if err != nil {
		fmt.Errorf("QuerySecurityKeyVersion Error : %s", err)
	}

	return skv
}

//查询当前启用的SecurityKeyVersion
func QueryCurrentEnableVersion() *SecurityKeyVersion {
	o := orm.NewOrm()
	var r orm.RawSeter
	var skv *SecurityKeyVersion
	r = o.Raw("SELECT version_id,version,status,incremental_factor,pcode_md5 FROM security_key_version WHERE del_flag = 1 AND status = 4 ")
	err := r.QueryRow(&skv)
	if err != nil {
		fmt.Errorf("QueryCurrentEnableVersion Error : %s", err)
	}

	return skv
}

//根据pcodeMd5查询多个SecurityPcode
func QuerySecurityPcode(pcodeMd5 string) *SecurityPcode {
	o := orm.NewOrm()
	var r orm.RawSeter
	var securityPcode *SecurityPcode
	r = o.Raw("SELECT pcode_id,pcode_md5,tpu_pcode_name,tpu_pcode,tpu_pcode_md5 FROM security_pcode WHERE pcode_md5  = ? ", pcodeMd5)
	err := r.QueryRow(&securityPcode)

	if err != nil {
		fmt.Errorf("SecurityPcode Error : %s", err)
	}
	return securityPcode
}
