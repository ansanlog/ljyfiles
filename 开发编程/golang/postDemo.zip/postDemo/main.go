package main

import (
	_ "postDemo/routers"
	"github.com/astaxie/beego"
)

func main() {
	beego.Run()
}

