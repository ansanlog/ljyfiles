package controllers

import (
	"github.com/astaxie/beego"
)

type NextCommandController struct {
	beego.Controller
}

func (c *NextCommandController)Post(){
	c.Ctx.WriteString("NextCommandController")

}
