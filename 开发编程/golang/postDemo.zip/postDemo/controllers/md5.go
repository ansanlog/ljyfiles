package controllers

import (
	"github.com/astaxie/beego"
)

type MD5Controller struct {
	beego.Controller
}

func (c *MD5Controller)Post(){
	c.Ctx.WriteString("MD5Controller")
}


