package controllers


import (
	"github.com/astaxie/beego"
)

type FileDownloadController struct {
	beego.Controller
}

func (c *FileDownloadController)Post(){
	c.Ctx.WriteString("FileDownloadController")

}
