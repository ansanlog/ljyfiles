package controllers


import (
	"github.com/astaxie/beego"
)

type LoginController struct {
	beego.Controller
}

func (c *LoginController)Post(){
	c.Ctx.WriteString("LoginController")

}
