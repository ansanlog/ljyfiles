package routers

import (
	"postDemo/controllers"
	"github.com/astaxie/beego"
)

func init() {
	/*beego.Router("/", &controllers.MainController{})*/
	beego.Router("/login", &controllers.LoginController{})
	beego.Router("/fileDownload", &controllers.FileDownloadController{})
	beego.Router("/md5", &controllers.MD5Controller{})
	beego.Router("/nextCommand", &controllers.NextCommandController{})
}
