package routers

import (
	"mifpay-upgrade-services/controllers"
	"github.com/astaxie/beego"
)

func init() {
	/*beego.Router("/", &controllers.MainController{})*/
	beego.Router("/upgrade", &controllers.UpgradeController{})
	/*beego.Router("/api/v1/generateSecurity", &controllers.SecurityController{}, "get:GenerateUpgrade")*/
}
