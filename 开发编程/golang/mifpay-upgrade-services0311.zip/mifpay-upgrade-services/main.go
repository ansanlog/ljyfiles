package main

import (
	_"mifpay-upgrade-services/routers"
	"github.com/astaxie/beego"
)

func main() {
	beego.Run()
}

