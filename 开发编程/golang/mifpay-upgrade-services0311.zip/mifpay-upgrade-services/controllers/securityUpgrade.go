package controllers
/*
import (
	"github.com/astaxie/beego"
	"fmt"
	"mifpay-upgrade-services/models"
	"strings"
	"encoding/hex"
	"os"
)


type SecurityController struct {
	beego.Controller
}

// 生成安全策略版本BLE升级包
func (c *SecurityController) GenerateUpgrade() {

	var version = c.GetString("version")
	//如果版本号参数为空，直接返回页面，提示version is empty
	if !(len(version) > 0) {
		var tmp = "param: version is empty."
		fmt.Printf(tmp)
		c.Ctx.WriteString(tmp)
	} else {
		var securityPcode *models.SecurityPcode
		//var version  int
		var incrementalFactor string
		var pcodeMd5 string
		var tpuPcode []byte
		//根据版本号查询数据，状态：未启用
		var securityKeyVersion *models.SecurityKeyVersion = models.QuerySecurityKeyVersion(version)
		if securityKeyVersion != nil {
			version = securityKeyVersion.Version
			incrementalFactor = securityKeyVersion.Version
			pcodeMd5 = securityKeyVersion.PcodeMd5
			//查询Pcode
			securityPcode = models.QuerySecurityPcode(pcodeMd5)
			tpuPcode = securityPcode.TpuPcode
		}
		//查询当前启用的数据，状态：已启用
		var securityEnableVersion *models.SecurityKeyVersion = models.QueryCurrentEnableVersion()
		if securityEnableVersion != nil {
			if strings.EqualFold(pcodeMd5, securityEnableVersion.PcodeMd5) {
				//与启用版本Pcode相同，则不用下发Pcode，用0x00替换
				tpuPcode = []byte{0x00}
			}

		}

		//增量因子转为字节数据
		iFactor, err := hex.DecodeString(incrementalFactor)
		if (err != nil) {
			fmt.Errorf("incrementalFactor transcoding error : %s", err)
		}
		//增量因子转为两个字节数据
		var iFactorLen = len(iFactor)
		var iFactorLenArr [2]byte
		iFactorLenArr[0] = byte(iFactorLen)
		iFactorLenArr[1] = byte(iFactorLen >> 8)

		//PCode转为四个字节数据
		var tpuPcodeLen = len(tpuPcode)
		var tpuPcodeLenArr [4]byte
		tpuPcodeLenArr[0] = byte(tpuPcodeLen)
		tpuPcodeLenArr[1] = byte(tpuPcodeLen >> 8)
		tpuPcodeLenArr[2] = byte(tpuPcodeLen >> 16)
		tpuPcodeLenArr[3] = byte(tpuPcodeLen >> 24)

		var bifac = iFactorLenArr[0:2]

		var bfactor []byte
		bfactor = append(bifac)
		//拼接增量因子字节数据
		for _, v := range iFactor {
			bfactor = append(bfactor, v)
		}
		//拼接PCode长度字节数据
		for _, v := range tpuPcodeLenArr {
			bfactor = append(bfactor, v)
		}
		//拼接PCode字节数据
		for _, v := range tpuPcode {
			bfactor = append(bfactor, v)
		}

		f, err1 := os.Create("./20170310_00400_0001.mif")  //创建文件
		check(err1)
		defer f.Close()
		n2, err2 := f.Write(bfactor)  //写入文件(字节数组)
		check(err2)
		fmt.Printf("写入 %d 个字节", n2)
		f.Sync()
		c.Ctx.WriteString("写入 %d 个字节", n2)
	}
}

*/

func check(e error) {
	if e != nil {
		panic(e)
	}
}
