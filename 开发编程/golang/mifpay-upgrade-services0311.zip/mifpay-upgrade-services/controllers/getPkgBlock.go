package controllers

import (
	"github.com/astaxie/beego"
	"bytes"
	"encoding/binary"
	"strings"
)

func getPkgBlock(res []byte) (repPkg []byte) {

	var (
		dataLen,blockNum int
		data []byte
	)

	bufDataLen := bytes.NewBuffer(res[4:6]) // 数据总长度
	binary.Read(bufDataLen, binary.LittleEndian, &dataLen)

	newRes := res[6:6 + dataLen] // token

	token := newRes[0:32]
	blockNumByte := newRes[32:]

	data = append([]byte(beego.AppConfig.String("user")))
	for _, v := range []byte(beego.AppConfig.String("pwd")) {
		data = append(data, v)
	}

	if strings.EqualFold(getToken(data), string(token)) {

		bufBlockNum := bytes.NewBuffer(blockNumByte)
		binary.Read(bufBlockNum, binary.LittleEndian, &blockNum)

		// 结果/数据块大小/数据
		buf := new(bytes.Buffer)
		binary.Write(buf, binary.LittleEndian, int16(0))
		repPkg = buf.Bytes()[0:1]

		// 数据块大小
		bufBlockSize := new(bytes.Buffer)
		binary.Write(bufBlockSize, binary.LittleEndian, int16(len(fileCache[blockNum])))
		for _, v := range bufBlockSize.Bytes()[0:2] {
			repPkg = append(repPkg, v)
		}
		// 数据
		for _, v := range fileCache[blockNum] {
			repPkg = append(repPkg, v)
		}
	} else {
		// 若获取失败，无哈希值与分块数量
		buf := new(bytes.Buffer)
		binary.Write(buf, binary.LittleEndian, int16(1))
		repPkg = buf.Bytes()[0:1]
	}
	return repPkg
}
