package controllers

import (
	"bytes"
	"github.com/astaxie/beego"
	"path/filepath"
	"os"
	"fmt"
	"encoding/binary"
	"strings"
)

var (
	fileSize int
	fileDir string
	fileName string
	fileHash []byte
	blockNum int
	fileCache map[int][]byte
)

func upgradePkg(res []byte) (repPkg []byte) {
	var (
		dataLen int
		data []byte
	)

	bufDataLen := bytes.NewBuffer(res[4:6]) // 数据总长度
	binary.Read(bufDataLen, binary.LittleEndian, &dataLen)

	newRes := res[6:6 + dataLen]  // token

	data = []byte(beego.AppConfig.String("user"))
	for _, v := range []byte(beego.AppConfig.String("pwd")) {
		data = append(data, v)
	}

	if strings.EqualFold(getToken(data), string(newRes)) {
		// 结果/哈希值/分块数量/文件名长度/文件名
		buf := new(bytes.Buffer)
		binary.Write(buf, binary.LittleEndian, int16(0)) // 结果
		repPkg = buf.Bytes()[0:1]

		fileSize = beego.AppConfig.DefaultInt("blockSize", 512)
		fileDir = getfile(beego.AppConfig.String("fileDir"))
		fileName, fileHash, blockNum = getFileInfo(fileDir, fileSize)

		// 哈希值
		for _, v := range fileHash {
			repPkg = append(repPkg, v)
		}
		// 分块数量
		bufBlockNum := new(bytes.Buffer)
		binary.Write(bufBlockNum, binary.LittleEndian, int16(blockNum))
		for _, v := range bufBlockNum.Bytes()[0:2] {
			repPkg = append(repPkg, v)
		}

		// 文件名长度
		bufFileNameSize := new(bytes.Buffer)
		binary.Write(bufFileNameSize, binary.LittleEndian, int16(len(fileName)))
		for _, v := range bufFileNameSize.Bytes()[0:2] {
			repPkg = append(repPkg, v)
		}

		// 文件名
		bufFileName := bytes.NewBufferString(fileName)
		for _, v := range bufFileName.Bytes() {
			repPkg = append(repPkg, v)
		}

		/*NewBufferString*/
		fmt.Println(len(fileName), fileName, fileHash, blockNum)

	} else {
		// 若获取失败，无哈希值与分块数量
		buf := new(bytes.Buffer)
		binary.Write(buf, binary.LittleEndian, int16(1))
		repPkg = buf.Bytes()[0:1]
	}
	return repPkg

}
func getfile(fileDir string) (file string) {

	filepath.Walk(fileDir,
		func(path string, f os.FileInfo, err error) error {
			if f == nil {
				return err
			}
			if f.IsDir() {
				/*fmt.Println("dir:", path)*/
				return nil
			}
			/*fmt.Println("file:", path)*/
			file = path
			return nil
		})
	return file
}
