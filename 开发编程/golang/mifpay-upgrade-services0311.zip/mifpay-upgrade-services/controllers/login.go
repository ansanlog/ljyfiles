package controllers

import (
	"github.com/astaxie/beego"
	"strings"
	"bytes"
	"encoding/binary"
)

func login(res []byte) (repPkg []byte) {

	var start, end ,dataLen ,resUserlen ,relPwdLen int

	bufDataLen := bytes.NewBuffer(res[4:6]) // 数据总长度
	binary.Read(bufDataLen, binary.LittleEndian, &dataLen)

	newRes := res[6:6 + dataLen] // 新切片

	bufResUserlen := bytes.NewBuffer(newRes[0:2]) // 用户长度
	binary.Read(bufResUserlen, binary.LittleEndian, &resUserlen)



	end = resUserlen + 2
	resUser := newRes[2:end] // 用户名

	start = end
	end = end + 2

	bufRelPwdLen := bytes.NewBuffer(newRes[start:end])
	binary.Read(bufRelPwdLen, binary.LittleEndian, &relPwdLen)// 密码长度

	start = end
	end = end + relPwdLen
	resPwd := newRes[start:end] // 密码

	// 调用MD5，生成token
	if strings.EqualFold(beego.AppConfig.String("user"), string(resUser))&& strings.EqualFold(beego.AppConfig.String("pwd"), string(resPwd)) {
		var data []byte
		data=resUser
		for _,v :=range resPwd{
			data=append(data,v)
		}
		repPkg=[]byte(getToken(data))
		buf := new(bytes.Buffer)
		binary.Write(buf, binary.LittleEndian, int16(0))
		repPkg = buf.Bytes()[0:1]
	} else {
		// 若获取失败，无哈希值与分块数量
		buf := new(bytes.Buffer)
		binary.Write(buf, binary.LittleEndian, int16(1))
		repPkg = buf.Bytes()[0:1]
	}
	return repPkg
}
