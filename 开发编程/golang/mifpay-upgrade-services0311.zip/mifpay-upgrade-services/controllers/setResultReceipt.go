package controllers

import (
	"github.com/astaxie/beego"
	"bytes"
	"encoding/binary"
	"strings"
)

func setResultReceipt(res []byte) (repPkg []byte) {
	var (
		dataLen int
		data []byte
	)

	bufDataLen := bytes.NewBuffer(res[4:6]) // 数据总长度
	binary.Read(bufDataLen, binary.LittleEndian, &dataLen)

	newRes := res[6:6 + dataLen] // token
	token := newRes[0:32]
	resultStatus := newRes[32:]

	data = append([]byte(beego.AppConfig.String("user")))

	for _, v := range []byte(beego.AppConfig.String("pwd")) {
		data = append(data, v)
	}

	if strings.EqualFold(getToken(data), string(token)) {

		// token/结果
		for _, v := range token {
			repPkg = append(repPkg, v)
		}

		// 结果
		for _, v := range resultStatus {
			repPkg = append(repPkg, v)
		}

	}

	return repPkg
}
