package controllers
/*
  根据接收到的数据，截取命令字转化为整形，由命令字决定做哪种操作
*/

import (
	"github.com/astaxie/beego"
	"bytes"
	"encoding/binary"
)

type UpgradeController struct {
	beego.Controller
}

func (this *UpgradeController) Post() {

	var CMD int
	res := this.Ctx.Input.RequestBody
	byteCWD := res[0:2]
	bufByteCWD := bytes.NewBuffer(byteCWD)
	binary.Read(bufByteCWD, binary.LittleEndian, &CMD)

	switch CMD {
	case 2:
		this.Ctx.Output.Body(login(res))
		/*this.Ctx.ResponseWriter.ResponseWriter.Write(login(res))*/
	case 3:
		this.Ctx.Output.Body(upgradePkg(res))
		/*this.Ctx.ResponseWriter.ResponseWriter.Write(upgradePkg(res))*/
	case 4:
		this.Ctx.Output.Body(getPkgBlock(res))
		/*this.Ctx.ResponseWriter.ResponseWriter.Write(getPkgBlock(res))*/

	case 5:
		this.Ctx.Output.Body(setResultReceipt(res))
		/*this.Ctx.ResponseWriter.ResponseWriter.Write(setResultReceipt(res))*/
	default:
		// 无法识别，回复0X9F0F
		buf := new(bytes.Buffer)
		binary.Write(buf, binary.LittleEndian, int16(3999))
		this.Ctx.Output.Body(buf.Bytes()[0:2])
		/*this.Ctx.ResponseWriter.ResponseWriter.Write([]byte("Unable to identify the key words"))*/
	}

}