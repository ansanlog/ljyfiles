package controllers

import (
	"os"
	"fmt"
	"io"
	"io/ioutil"
)


func getFileInfo(fl string,size int) (fileName string,fileHash []byte,blockNum int){

	file, err := os.Open(fl)
	if err != nil {
		fmt.Println("failed to open:", file)
	}

	fd,err := ioutil.ReadAll(file)
	fileHash=[]byte(getToken(fd)) // 哈希值
	defer file.Close()

	finfo, err := file.Stat()
	if err != nil {
		fmt.Println("get file info failed:", file, size)
	}
	fileName=finfo.Name()
	//每次最多拷贝1m
	/*bufsize := 1024 * 1024

	if size < bufsize {
		bufsize = size
	}*/

	blockNum = (int(finfo.Size()) + size - 1) / size // 文件分块量
	buf := make([]byte, size)
	fileCache=make(map[int][]byte,blockNum)
	for i := 0; i < blockNum; i++ {
		copylen := 0
		// 分块文件规则分块序号+原文件名
		/*newfilename :=  strconv.Itoa(i)+finfo.Name()
		newfile, err1 := os.Create(newfilename)
		if err1 != nil {
			fmt.Println("failed to create file", newfilename)
		} else {
			fmt.Println("create file:", newfilename)
		}*/
		for copylen < size {
			n, err2 := file.Read(buf)
			if err2 != nil && err2 != io.EOF {
				fmt.Println(err2, "failed to read from:", file)
				break
			}
			if n <= 0 {
				break
			}
			w_buf := buf[:n]
			fileCache[i]=w_buf
			/*newfile.Write(w_buf)*/
			copylen += n

		}
		/*newfile.Close()*/
	}
	return fileName,fileHash,blockNum

}


/*func SplitFile(file *os.File, size int) {
	finfo, err := file.Stat()
	if err != nil {
		fmt.Println("get file info failed:", file, size)
	}

	fmt.Println(finfo, size)

	//每次最多拷贝1m
	*//*bufsize := 1024 * 1024

	if size < bufsize {
		bufsize = size
	}*//*
	buf := make([]byte, size)
	num := (int(finfo.Size()) + size - 1) / size // 整数块
	fmt.Println(num, len(buf))

	for i := 0; i < num; i++ {
		copylen := 0
		newfilename := finfo.Name() + strconv.Itoa(i)
		newfile, err1 := os.Create(newfilename)
		if err1 != nil {
			fmt.Println("failed to create file", newfilename)
		} else {
			fmt.Println("create file:", newfilename)
		}
		for copylen < size {
			n, err2 := file.Read(buf)
			if err2 != nil && err2 != io.EOF {
				fmt.Println(err2, "failed to read from:", file)
				break
			}
			if n <= 0 {
				break
			}
			//fmt.Println(n, len(buf))
			//写文件
			w_buf := buf[:n]
			newfile.Write(w_buf)
			copylen += n
		}
	}

	return
}*/




