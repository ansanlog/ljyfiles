package com.mifpay.collect.dao;

import com.mifpay.collect.bo.RechargeDetail;

public interface IRechargeDetailDao {
//    int deleteByPrimaryKey(Integer detailId);
//
//    int insert(RechargeDetail record);

    int insertSelective(RechargeDetail record);

//    RechargeDetail selectByPrimaryKey(Integer detailId);

//    int updateByPrimaryKeySelective(RechargeDetail record);
//
//    int updateByPrimaryKey(RechargeDetail record);
}