package com.mifpay.collect.service.impl;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.alibaba.fastjson.JSON;
import com.mifpay.collect.bo.SubwayConsumeDetail;
import com.mifpay.collect.dao.ISubwayConsumeDetailDao;
import com.mifpay.collect.service.ISubwayConsumeDetailService;
import com.mifpay.util.BeanCopierUtil;

/**
 * 保存待清算充值订单数据
 * 
 * @version 1.0
 *
 * @author ljy
 *
 * @Create 2016年1月13日 下午4:38:01
 * 
 * @History ljy 2016年1月13日 Create the class <br>
 */
@Service("subwayConsumeDetailService")
public class SubwayConsumeDetailServiceImpl implements ISubwayConsumeDetailService {

    private static final Logger LOGGER = LoggerFactory.getLogger(SubwayConsumeDetailServiceImpl.class);

    @Autowired
    private ISubwayConsumeDetailDao subwayConsumeDetailDao;

    /**
     * 保存待清算充值订单数据
     * 
     * @param msgList
     */
    @Override
    public void insertSubwayConsumeDetail(SubwayConsumeDetail subwayConsumeDetail) {
        Assert.notNull(subwayConsumeDetail, "the parameter subwayConsumeDetail is null.");

        // 充值记录插入清算库
        SubwayConsumeDetail tosubwayConsumeDetail = new SubwayConsumeDetail();
        BeanCopierUtil.copyProperties(subwayConsumeDetail, tosubwayConsumeDetail);
        // toRechargeDetail.setOrderId(rechargeDetail.getOrderId().intValue());
        // toRechargeDetail.setUserId(rechargeDetail.getUserId().intValue());
        // toRechargeDetail.setPartnerId(rechargeDetail.getPartnerId().intValue());
        // toRechargeDetail.setTradeAmount(rechargeDetail.getRealAmount());
        // toRechargeDetail.setBalance(rechargeDetail.getBalance());
        tosubwayConsumeDetail.setCheckStatus(0);
        /* 默认待清分状态 */
        tosubwayConsumeDetail.setLiquidateStatus(1);
        /* 清分状态更新时间 */
        tosubwayConsumeDetail.setUpdateTime(new Date());
        /* 创建时间 */
        tosubwayConsumeDetail.setCreateTime(new Date());
        subwayConsumeDetailDao.insertSelective(tosubwayConsumeDetail);
        LOGGER.info("清分库存入一笔消费订单[{}]", JSON.toJSONString(tosubwayConsumeDetail));
    }

    /**
     * 应用健康检查
     *
     * @author: 梁安宁 lianganning@mifpay.net
     * @create: 2016年6月22日 下午6:40:50
     *
     * @return
     */
    @Override
    public boolean health() {
        return true;
    }
}
