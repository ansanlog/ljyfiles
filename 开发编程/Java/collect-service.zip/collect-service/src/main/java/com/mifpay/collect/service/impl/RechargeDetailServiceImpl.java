package com.mifpay.collect.service.impl;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.alibaba.fastjson.JSON;
import com.mifpay.collect.bo.RechargeDetail;
import com.mifpay.collect.dao.IRechargeDetailDao;
import com.mifpay.collect.service.IRechargeDetailService;
import com.mifpay.util.BeanCopierUtil;

/**
 * 保存待清算充值订单数据
 * 
 * @version 1.0
 * 
 * @author ljy
 * 
 * @Create 2016年1月13日 下午4:38:01
 * 
 * @History ljy 2016年1月13日 Create the class <br>
 */
@Service("rechargeDetailService")
public class RechargeDetailServiceImpl implements IRechargeDetailService {

    private static final Logger LOGGER = LoggerFactory.getLogger(RechargeDetailServiceImpl.class);

    @Autowired
    private IRechargeDetailDao rechargeDetailDao;

    /**
     * 保存待清算充值订单数据
     * 
     * @param msgList
     */
    @Override
    public void insertRechargeDetail(RechargeDetail rechargeDetail) {
        Assert.notNull(rechargeDetail, "the parameter rechargeDetail is null.");

        // 充值记录插入清算库
        RechargeDetail toRechargeDetail = new RechargeDetail();
        BeanCopierUtil.copyProperties(rechargeDetail, toRechargeDetail);
        // toRechargeDetail.setOrderId(rechargeDetail.getOrderId().intValue());
        // toRechargeDetail.setUserId(rechargeDetail.getUserId().intValue());
        // toRechargeDetail.setPartnerId(rechargeDetail.getPartnerId().intValue());
        // toRechargeDetail.setTradeAmount(rechargeDetail.getRealAmount());
        // toRechargeDetail.setBalance(rechargeDetail.getBalance());
        toRechargeDetail.setCheckStatus(0);
        /* 默认待清分状态 */
        toRechargeDetail.setLiquidateStatus(1);
        Date updateTime = new Date();
        /* 清分状态更新时间 */
        toRechargeDetail.setUpdateTime(updateTime);
        /* 创建时间 */
        toRechargeDetail.setCreateTime(updateTime);
        rechargeDetailDao.insertSelective(toRechargeDetail);
        LOGGER.info("清分库存入一笔充值订单[{}]", JSON.toJSONString(toRechargeDetail));
    }
}
