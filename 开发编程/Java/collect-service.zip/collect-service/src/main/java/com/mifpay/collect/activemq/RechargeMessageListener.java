package com.mifpay.collect.activemq;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;
import com.mifpay.collect.bo.RechargeDetail;
import com.mifpay.collect.service.IRechargeDetailService;

/**
 * 接收充值交易数据
 * 
 * @version 1.0
 * 
 * @author ljy
 * 
 * @Create 2016年1月13日 下午5:05:05
 * 
 * @History ljy 2016年1月13日 Create the class <br>
 * 
 */
public class RechargeMessageListener implements MessageListener {
    private static final Logger LOGGER = LoggerFactory.getLogger(RechargeMessageListener.class);

    @Autowired
    private IRechargeDetailService rechargeDetailService;

    /**
     * 接收待清算充值订单消息
     * 
     * @param message
     */
    @Override
    public void onMessage(Message message) {
        TextMessage msg = (TextMessage) message;
        RechargeDetail rechargeDetail = null;
        try {
            rechargeDetail = JSON.parseObject(msg.getText(), RechargeDetail.class);
            if (null != rechargeDetail) {
                rechargeDetailService.insertRechargeDetail(rechargeDetail);
            }
        } catch (JMSException e) {
        } finally {
            if (null != rechargeDetail) {
                LOGGER.debug("接收到的待清算充值订单数据：" + JSON.toJSONString(rechargeDetail));
            }
        }
    }
}
