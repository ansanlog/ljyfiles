package com.mifpay.collect.service;

import com.mifpay.collect.bo.SubwayConsumeDetail;

/**
 * 保存待清算充值订单数据
 * 
 * @version 1.0
 *
 * @author ljy
 *
 * @Create 2016年1月13日 下午4:38:01
 * 
 * @History ljy 2016年1月13日 Create the class <br>
 */

public interface ISubwayConsumeDetailService {

    /**
     * 保存待清算充值订单数据
     * 
     * @param msgList
     */
    public void insertSubwayConsumeDetail(SubwayConsumeDetail subwayConsumeDetail);

    /**
     * 应用健康检查
     *
     * @author: 梁安宁 lianganning@mifpay.net
     * @create: 2016年6月22日 下午6:40:50
     *
     * @return
     */
    public boolean health();

}
