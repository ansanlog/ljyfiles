package com.mifpay.collect.service;

import com.mifpay.collect.bo.RechargeDetail;

/**
 * 保存待清算充值订单数据
 * 
 * @version 1.0 
 *
 * @author ljy
 *
 * @Create 2016年1月13日 下午4:38:01
 * 
 * @History ljy 2016年1月13日 Create the class <br>
 */

public interface IRechargeDetailService {
	
	/**
     * 保存待清算充值订单数据
     * 
     * @param msgList
     */
    public void insertRechargeDetail(RechargeDetail rechargeDetail);

}
