package com.mifpay.collect.bo;

import java.math.BigDecimal;
import java.util.Date;

public class RechargeDetail {
    private Integer detailId;

    private Long orderId;

    private String tradeName;

    private String tradeType;

    private Long userId;

    private String userName;

    private String intoAccount;

    private String partnerCode;

    private String partnerName;

    private String paymentType;

    private String rechargeFrom;

    private String payerAccount;

    private String channelCode;

    private String channelName;

    private String tradeSn;

    private String payerSn;

    private String tradeStatus;

    private BigDecimal tradeAmount;

    private BigDecimal orderRebate;

    private BigDecimal realAmount;

    private BigDecimal balance;

    private Date tradeTime;

    private Date bankTradeTime;

    private Date createTime;

    private String mobile;

    private String rechargeVoucher;

    private String securityVersion;
    
    private Integer checkStatus;

    private Integer liquidateStatus;

    private Date updateTime;

    public Integer getDetailId() {
        return detailId;
    }

    public void setDetailId(Integer detailId) {
        this.detailId = detailId;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getTradeName() {
        return tradeName;
    }

    public void setTradeName(String tradeName) {
        this.tradeName = tradeName == null ? null : tradeName.trim();
    }

    public String getTradeType() {
        return tradeType;
    }

    public void setTradeType(String tradeType) {
        this.tradeType = tradeType == null ? null : tradeType.trim();
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName == null ? null : userName.trim();
    }

    public String getIntoAccount() {
        return intoAccount;
    }

    public void setIntoAccount(String intoAccount) {
        this.intoAccount = intoAccount == null ? null : intoAccount.trim();
    }

    public String getPartnerCode() {
        return partnerCode;
    }

    public void setPartnerCode(String partnerCode) {
        this.partnerCode = partnerCode == null ? null : partnerCode.trim();
    }

    public String getPartnerName() {
        return partnerName;
    }

    public void setPartnerName(String partnerName) {
        this.partnerName = partnerName == null ? null : partnerName.trim();
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType == null ? null : paymentType.trim();
    }

    public String getRechargeFrom() {
        return rechargeFrom;
    }

    public void setRechargeFrom(String rechargeFrom) {
        this.rechargeFrom = rechargeFrom == null ? null : rechargeFrom.trim();
    }

    public String getPayerAccount() {
        return payerAccount;
    }

    public void setPayerAccount(String payerAccount) {
        this.payerAccount = payerAccount == null ? null : payerAccount.trim();
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode == null ? null : channelCode.trim();
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName == null ? null : channelName.trim();
    }

    public String getTradeSn() {
        return tradeSn;
    }

    public void setTradeSn(String tradeSn) {
        this.tradeSn = tradeSn == null ? null : tradeSn.trim();
    }

    public String getPayerSn() {
        return payerSn;
    }

    public void setPayerSn(String payerSn) {
        this.payerSn = payerSn == null ? null : payerSn.trim();
    }

    public String getTradeStatus() {
        return tradeStatus;
    }

    public void setTradeStatus(String tradeStatus) {
        this.tradeStatus = tradeStatus == null ? null : tradeStatus.trim();
    }

    public BigDecimal getTradeAmount() {
        return tradeAmount;
    }

    public void setTradeAmount(BigDecimal tradeAmount) {
        this.tradeAmount = tradeAmount;
    }

    public BigDecimal getOrderRebate() {
        return orderRebate;
    }

    public void setOrderRebate(BigDecimal orderRebate) {
        this.orderRebate = orderRebate;
    }

    public BigDecimal getRealAmount() {
        return realAmount;
    }

    public void setRealAmount(BigDecimal realAmount) {
        this.realAmount = realAmount;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(BigDecimal balance) {
        this.balance = balance;
    }

    public Date getTradeTime() {
        return tradeTime;
    }

    public void setTradeTime(Date tradeTime) {
        this.tradeTime = tradeTime;
    }

    public Date getBankTradeTime() {
        return bankTradeTime;
    }

    public void setBankTradeTime(Date bankTradeTime) {
        this.bankTradeTime = bankTradeTime;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }

    public String getRechargeVoucher() {
        return rechargeVoucher;
    }

    public void setRechargeVoucher(String rechargeVoucher) {
        this.rechargeVoucher = rechargeVoucher == null ? null : rechargeVoucher.trim();
    }

    public String getSecurityVersion() {
        return securityVersion;
    }

    public void setSecurityVersion(String securityVersion) {
        this.securityVersion = securityVersion == null ? null : securityVersion.trim();
    }
    
    public Integer getCheckStatus() {
        return checkStatus;
    }

    public void setCheckStatus(Integer checkStatus) {
        this.checkStatus = checkStatus;
    }

    public Integer getLiquidateStatus() {
        return liquidateStatus;
    }

    public void setLiquidateStatus(Integer liquidateStatus) {
        this.liquidateStatus = liquidateStatus;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}