package com.mifpay.collect.dao;

import com.mifpay.collect.bo.SubwayConsumeDetail;

public interface ISubwayConsumeDetailDao {
//    int deleteByPrimaryKey(Integer detailId);

//    int insert(SubwayConsumeDetail record);

    int insertSelective(SubwayConsumeDetail record);

//    SubwayConsumeDetail selectByPrimaryKey(Integer detailId);

//    int updateByPrimaryKeySelective(SubwayConsumeDetail record);

//    int updateByPrimaryKey(SubwayConsumeDetail record);
}