package com.mifpay.collect.activemq;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSON;
import com.mifpay.collect.bo.SubwayConsumeDetail;
import com.mifpay.collect.service.ISubwayConsumeDetailService;

/**
 * 接收地铁消费数据
 * 
 * @version 1.0
 * 
 * @author ljy
 * 
 * @Create 2016年1月13日 下午5:05:05
 * 
 * @History ljy 2016年1月13日 Create the class <br>
 * 
 */
public class ConsumeMessageListener implements MessageListener {
    private static final Logger LOGGER = LoggerFactory.getLogger(ConsumeMessageListener.class);

    @Autowired
    private ISubwayConsumeDetailService subwayConsumeDetailService;

    /**
     * 接收待清算充值订单消息
     * 
     * @param message
     */
    @Override
    public void onMessage(Message message) {
        TextMessage msg = (TextMessage) message;
        SubwayConsumeDetail subwayConsumeDetail = null;
        try {

            subwayConsumeDetail = JSON.parseObject(msg.getText(), SubwayConsumeDetail.class);
            if (null != subwayConsumeDetail) {
                subwayConsumeDetailService.insertSubwayConsumeDetail(subwayConsumeDetail);
            }
        } catch (JMSException e) {
        } finally {
            if (null != subwayConsumeDetail) {
                LOGGER.debug("接收到的待清算消费订单数据：" + JSON.toJSONString(subwayConsumeDetail));
            }
        }
    }
}
