package com.mifpay.collect.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mifpay.collect.service.ISubwayConsumeDetailService;
import com.mifpay.util.SpringBeans;

/**
 * Servlet implementation class CheckHealth
 */
public class CheckHealth extends HttpServlet {
    private Logger LOGGER = LoggerFactory.getLogger(getClass());

    private static final long serialVersionUID = 1L;
    protected final static String CHARSET = "utf-8";

    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckHealth() {
        super();
    }

    /**
     * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
     */
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException,
            IOException {
        response.setContentType("text/html; charset=" + CHARSET);

        try {
            ISubwayConsumeDetailService subwayConsumeDetailService = (ISubwayConsumeDetailService) SpringBeans
                    .getBean("subwayConsumeDetailService");
            if (null == subwayConsumeDetailService) {
                writeHealthError(response);
            } else if (subwayConsumeDetailService.health()) {
                response.getWriter().print("hello world");
            } else {
                throw new RuntimeException("error");
            }

        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            writeHealthError(response);
        }
    }

    protected void writeHealthError(HttpServletResponse rsp) {
        PrintWriter pw = null;
        try {
            rsp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            pw = rsp.getWriter();
            pw.flush();
            pw.close();
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
        } finally {
            if (pw != null) {
                pw.close();
            }
        }
    }

}
